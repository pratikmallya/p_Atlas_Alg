function [data y] = singular(prob, data, u)
  y = 1;
end