function [prob atlas cseg correct] = predict(atlas, prob, cseg)
chart       = atlas.base_chart;
prcond      = struct('x', chart.x, 'TS', chart.TS, ...
                     's', chart.s, 'h', chart.R);
xp          = chart.x+chart.R*(chart.TS*chart.s);
[prob cseg] = CurveSegment.create(prob, chart, prcond, xp);
correct     = true;
end
