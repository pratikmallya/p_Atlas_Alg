function cont = get_settings(cont)

defaults.h    = 0.1;
defaults.PtMX = 50 ;
cont          = coco_merge(defaults, cont);

end