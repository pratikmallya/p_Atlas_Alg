function [prob atlas cseg] = flush(atlas, prob, cseg)

[prob atlas cseg] = atlas.flush@AtlasBase(prob, cseg);
if cseg.Status==cseg.CurveSegmentOK
  atlas.base_chart = cseg.ptlist{end};
  if atlas.base_chart.pt>=atlas.cont.PtMX
    cseg.Status = cseg.BoundaryPoint;
  end
end

end