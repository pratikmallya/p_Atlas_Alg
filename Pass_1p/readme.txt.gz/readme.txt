This implements a 1-dimensional advancing front atlas algorithm
with constant step size and pseudo-arclength-based projection
condition and predictor.