function [data y] = empty(prob, data, u)
  y = u(1)^2+u(2)^2+1;
end