echo on
%!tkn1
prob = coco_add_func(coco_prob(), 'circle', @circle, [], ...
  'zero', 'u0', [1.5; 1]);
prob = coco_set(prob, 'cont', 'PtMX', 30);
coco(prob, '1', [], 1);
return
%!tkn2
prob = coco_add_pars(prob, '', [1 2], {'x' 'y'});
coco(prob, '1', [], 1, {'x' 'y'});
%!tkn3
data.MX = true;
prob = coco_add_func(coco_prob(), 'func', @circle, data, ...
  'zero', 'u0', [1.5; 1]);
prob = coco_add_pars(prob, '', [1 2], {'x' 'y'});
coco(prob, '1', [], 1, {'x' 'y'});
%!tkn4
prob = coco_add_func(coco_prob(), 'func', @empty, [], ...
  'zero', 'u0', [1; 1]);
coco(prob, '1', [], 1);
%!tkn5
prob = coco_add_func(coco_prob(), 'func', @singular, [], ...
  'zero', 'u0', [1; 1]);
coco(prob, '1', [], 1);
%!tkn6
prob = coco_add_func(coco_prob(), 'func', @circle, [], ...
  'zero', 'u0', [2; 0]);
coco(prob, '1', [], 1);
%!tkn7
prob = coco_add_func(coco_prob(), 'lemniscate', @lemniscate, ...
  [], 'zero', 'u0', [0; 0]);
prob = coco_add_pars(prob, '', [1 2], {'x' 'y'});
coco(prob, '1', [], 1, {'x' 'y'});
%!tkn8
prob = coco_add_func(coco_prob(), 'lemniscate', @lemniscate, ...
  [], 'zero', 'u0', [0; 0], 't0', [1; 1]);
prob = coco_add_pars(prob, '', [1 2], {'x' 'y'});
coco(prob, '1', [], 1, {'x' 'y'});
%!tkn9
echo off
%% test PtMX
% PtMX >= 0
prob = coco_prob();
prob = coco_set(prob, 'cont', 'atlas', @atlas_1d_min.create);
pprob = coco_set(prob, 'cont', 'PtMX', 30);
pprob = coco_add_func(pprob, 'circle', @circle, [], 'zero', 'u0', [1.5;1] );
pprob = coco_add_pars(pprob, '', [1 2], {'x' 'y'});
coco(pprob, '1', [], 1, {'x' 'y'});
% PtMX == 0
pprob = coco_set(prob, 'cont', 'PtMX', 0);
pprob = coco_add_func(pprob, 'circle', @circle, [], 'zero', 'u0', [1.5;1] );
pprob = coco_add_pars(pprob, '', [1 2], {'x' 'y'});
coco(pprob, '1', [], 1, {'x' 'y'});
% PtMX <= 0
pprob = coco_set(prob, 'cont', 'PtMX', -30);
pprob = coco_add_func(pprob, 'circle', @circle, [], 'zero', 'u0', [1.5;1] );
pprob = coco_add_pars(pprob, '', [1 2], {'x' 'y'});
coco(pprob, '1', [], 1, {'x' 'y'});
